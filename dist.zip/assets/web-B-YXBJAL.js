import{W as n}from"./index-BvGn4c0W.js";import"./vendor-md-editor-CdTWBvcx.js";import"./vendor-markdown-C9VizG7P.js";class t extends n{async show(e){}async hide(e){}}export{t as SplashScreenWeb};
